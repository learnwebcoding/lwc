document.write(
 '<h2>JavaScript Technique: Breadcrumbs Navigation</h2>' +
 '<div><b>Breadcrumbs navigation:</b> <span id="bcrumbsNavElement">Not applicable to web site home page. To start displaying breadcrumbs navigation, click a hyperlink below.</span></div>'
);