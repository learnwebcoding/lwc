<?php
/* -------------------- INTRODUCTION -------------------- */

/* File: stylesheets/stylesheets.php.
 * Purpose: HTML link element code for external and embedded style sheets.
 * Used in: index.php.
 * Last reviewed/updated: 20 Apr 2017.
 * Published: 20 Apr 2017. */
return
 "<link rel='stylesheet' type='text/css' media='all' href='stylesheets/lwc.css' />
  <link rel='stylesheet' type='text/css' media='all' href='stylesheets/simple_mysql_admin.css' />";