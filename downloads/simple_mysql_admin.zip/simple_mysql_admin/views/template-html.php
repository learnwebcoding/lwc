<?php
/* -------------------- INTRODUCTION -------------------- */

/* File: views/template-html.php.
 * Purpose: Template page view.
 * Used in: controllers/template.php.
 * Last reviewed/updated: 15 Jul 2017.
 * Last reviewed/updated for XSS: 31 May 2017.
 * Published: 14 May 2017.
 * Forms: None. */

/* ---------- ASSIGNMENTS ---------- */

/* ---------- VIEW ---------- */

return "Template View";
