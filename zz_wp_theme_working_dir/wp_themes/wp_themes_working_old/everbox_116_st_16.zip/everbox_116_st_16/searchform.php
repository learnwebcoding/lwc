<div class="widget-content">
	<form role="search" method="get" id="searchform" class="searchform" action="<?php echo esc_url(home_url('/')); ?>">
		<div class="input-group">
			<input type="text" class="form-control" value="" name="s" id="s">
			<span class="input-group-btn">
				<button type="submit" class="btn-primary"><?php _e('Go', 'everbox') ?></button>
			</span>
		</div>
	</form>
</div>
<!-- END .widget-content -->