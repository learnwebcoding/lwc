<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package EverBox
 * ST edit. Last reviewed/updated: 14 Feb 2019.
 */
?><!DOCTYPE HTML>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<?php wp_head(); ?>
	<link rel="stylesheet" type="text/css" media="all" href="https://www.learnwebcoding.com/stylesheets/bootstrap/bootstrap.min.css" /><!-- ST edit. Required for LWC navbar and LWC Bootstrap navbar. --><!-- NOTE: Loading lwc.css in LWC Blog/Forums causes issues. To avoid loading lwc.css in LWC Blog/Forums, place styles for LWC navbar at bottom of bootstrap.css, not in lwc.css. -->
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script><!-- ST edit. Required for LWC Bootstrap navbar. -->
	<script type="text/javascript" src="https://www.learnwebcoding.com/javascripts/bootstrap/bootstrap.min.js"></script><!-- ST edit. Required for LWC Bootstrap navbar. -->
</head>
<body <?php body_class(); ?>>
	<div id="page" class="hfeed site">
		<!-- ST edit. Replace EverBox header element content with LWC Home header element content, which is LWC navbar HTML and LWC Bootstrap navbar HTML. -->
		<header id="headerId">
			<nav class="lwc-navbar"><!-- Open LWC navbar HTML. --><!-- NOTE: Loading lwc.css in LWC Blog/Forums causes issues. To avoid loading lwc.css in LWC Blog/Forums, place styles for LWC navbar at bottom of bootstrap.css, not in lwc.css. -->
				<div class="container-fluid"><!-- container-fluid from Bootstrap. -->
					<div class="lwc-navbar-content"><a href="https://www.learnwebcoding.com/">Home</a>&nbsp;&nbsp;&bull;&nbsp;&nbsp;<a href="https://forums.learnwebcoding.com/">Forums</a>&nbsp;&nbsp;&bull;&nbsp;&nbsp;Ad Free!</div>
				</div>
			</nav><!-- Close LWC navbar HTML. -->

			<nav class="navbar navbar-inverse navbar-static-top"><!-- Open LWC Bootstrap navbar HTML. --><!-- navbar-static-top aligns navbar-right content flush to right edge and removes border-top. -->
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a href="https://blog.learnwebcoding.com/" class="navbar-brand"><span class="hidden-xs hidden-sm">Learn Web Coding Blog</span><span class="visible-xs visible-sm">LWC Blog</span></a>
					</div>
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">
							<li><a href="/?cat=1">HTML</a></li>
							<li><a href="/?cat=3">CSS</a></li>
							<li><a href="/?cat=4">JavaScript</a></li>
							<li><a href="/?cat=5">PHP</a></li>
							<li><a href="/?cat=6">Misc</a></li>
						</ul>
					</div>
				</div>
			</nav><!-- Close LWC Bootstrap navbar HTML. -->
		</header>
		<!--  ST edit. Close replace EverBox header element content with LWC Home header element content, which is LWC navbar HTML and LWC Bootstrap navbar HTML. -->
		<div class="container-fluid"><!-- ST edit. NOTE: If change to class="container", then sidebar does not show/hide properly, and this sidebar show/hide issue occurs regardless if header above uses class="container-fluid" or class="container". Therefore, leave as class="container-fluid" and change .container-fluid styles to be like .container styles. -->
			<div id="content" class="site-content group">